﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace produttore_consumatore_2._0
{
    class produttore_sequenziale : interfaccia_produttore
    {
//attributi
        private int id;
        private buffer bf;
        private int n=10;
//costruttore
        public produttore_sequenziale(int ID, buffer buf)
        {
            id = ID;
            bf = buf;
            Console.WriteLine("sono il produttore_sequenziale {0}", id);
        }
//metodi
        public void mostrastato()
        {
            Console.Write("P_S {0}, ", id);
            ProduciElemento();
            bf.mostrastato();
        }

        public async void ProduciElemento()
        {
            bool aggiunto;
            n += 1;
            lock (bf)
            {
                aggiunto = bf.ProvaAdAggiungere(n);
            }

            if (aggiunto)
            {
                Console.Write("aggiunto elemento {0} al buffer,                     ", n);
            }
            else
            {
                Console.Write("impossibilitato ad aggiungere elemento {0} al buffer,", n);
                //async
                bool done = false;
                while (!done)
                {
                    done = await Task.Run(() => bf.attendibufferAsync());
                    Console.WriteLine("il buffer si è liberato per P_S {0}", id);
                }
                //fine async
            }

        }

        public void Run() 
        {
            while (true)
            {
                mostrastato();
                Random rnd = new Random();
                Thread.Sleep(rnd.Next(1000,5000));
            }
        }
    }
}
