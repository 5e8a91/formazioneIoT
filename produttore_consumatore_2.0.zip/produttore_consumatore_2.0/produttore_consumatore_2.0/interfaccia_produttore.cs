﻿
namespace produttore_consumatore_2._0
{
    interface interfaccia_produttore
    {
        void ProduciElemento();
    }
}
