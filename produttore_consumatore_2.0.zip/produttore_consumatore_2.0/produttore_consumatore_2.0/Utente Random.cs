﻿using System;
using System.Threading;

namespace produttore_consumatore_2._0
{
 public abstract class Utente_Random
    {
//attributi
        protected int id;
        protected buffer bf;
        protected Random rnd;
//metodi
        public abstract void mostrastato();
        
        public virtual void Run()  //eventualmente riscrivibile in override
        {
            while (true) { 
            mostrastato();
            Thread.Sleep(rnd.Next(1000, 5000));
            }
        }

    }

    
}
