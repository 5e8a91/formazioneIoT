﻿using System;
using System.Threading.Tasks;

namespace produttore_consumatore_2._0
{
    public class Consumatore_random : Utente_Random, Interfaccia_consumatore
    {
        //costruttore
        public Consumatore_random(int ID, buffer buf)
        {
            id = ID;
            bf = buf;
            rnd = new Random((int)DateTime.Now.Ticks+id & 0x0000FFFF);
            Console.WriteLine("sono il consumatore_Random {0}", id);
        }
        //metodi
        public override void mostrastato()
        {
            Console.Write("C_R {0}, ", id);
            ConsumaElemento();
            bf.mostrastato();
        }

        public async void ConsumaElemento()
        {
            bool rimosso;

            lock (bf)
            {
                rimosso = bf.ProvaARimuovere();
            }
            if (rimosso)
                {
                    Console.Write("rimosso dal buffer,                              ");
                }
                else
                {
                    Console.Write("impossibilitato a rimuovere elementi dal buffer, ");
                //async
                bool done=false;
                    while (!done)
                    {
                     done= await Task.Run(()=> bf.attendibufferAsync());
                    Console.WriteLine("il buffer si è liberato per C_R {0}", id);
                    }
                //fine async
                }
           
        }
    }
}
