﻿
namespace produttore_consumatore_2._0
{
    interface Interfaccia_consumatore
    {
        void ConsumaElemento();
    }
}
