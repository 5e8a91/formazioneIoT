﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace produttore_consumatore_2._0
{
   public class buffer
    {
//attributi
        private int Dimensionebuffer;
        private int nelementi = 0;
        private List<int> lista = new List<int>();
//costruttore
        public buffer(int dimensione)
        {
            if (dimensione >= 0)
            {
                Dimensionebuffer = dimensione;
            }
            else
            {
                Dimensionebuffer = -dimensione;
            }
            Console.WriteLine("dimensione buffer settata a: {0}", Dimensionebuffer);
        }
//metodi
 public bool IsFull()
        {
            if (nelementi > Dimensionebuffer)
            {
                Console.WriteLine("errore! numero elementi: {0}", nelementi);
                return true;
            }

            if (Dimensionebuffer == nelementi)
            {
                return true;
            }
            else
            {
                return false;
            }
        }



 public bool IsEmpty()
        {
            if(nelementi < 0){
                Console.WriteLine("errore! numero elementi: {0}", nelementi );
                return true;
            }

            if (nelementi==0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }



 public bool ProvaAdAggiungere(int n)
        {
            if (!IsFull())
            {
                nelementi += 1;
                lista.Add(n);
                return true;
            }
            else
            {
                return false;
            }
        }



 public bool ProvaARimuovere()
        {
            if (!IsEmpty())
            {
                nelementi -= 1;
                Console.Write("{0} ", lista.ElementAt(nelementi));
                lista.RemoveAt(nelementi);
                return true;
            }
            else
            {
                return false;
            }
        }

 public void mostrastato()
        {
            Console.Write("BF={0}   ", nelementi);
            Console.WriteLine(String.Join(", ", lista));
            Console.WriteLine();
        }

//async

public void attendibufferAsync() {
            while(IsFull() || IsEmpty())
            {
             
            }
        }
//fine async
    }
}
