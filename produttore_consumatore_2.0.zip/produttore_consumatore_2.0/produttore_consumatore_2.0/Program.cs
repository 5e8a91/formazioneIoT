﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace produttore_consumatore_2._0
{
    class Program
    {
        private int Nproduttori = -1;
        private int Nproduttoriseq = -1;
        private int Nconsumatori = -1;
        private List<Consumatore_random> consumatori = new List<Consumatore_random>();
        private List<Produttore_Random> produttori = new List<Produttore_Random>();
        private List<produttore_sequenziale> produttoriseq = new List<produttore_sequenziale>();
        private List<Thread> Threadlistc = new List<Thread>();
        private List<Thread> Threadlistp = new List<Thread>();
        private List<Thread> Threadlistpseq = new List<Thread>();

        static void Main(string[] args)
        {
            Program pg = new Program();
            pg.RunAll();
        }

        private Program()
        {
            Console.WriteLine("setup avviato");

            Console.WriteLine("inserisci la dimensione del buffer: ");
            buffer bf = new buffer(Convert.ToInt32(Console.ReadLine()));

            while (Nproduttori < 0)
            {
                Console.WriteLine("inserisci il numero di produttori: ");
                Nproduttori = Convert.ToInt32(Console.ReadLine());
                if (Nproduttori < 0) { Console.WriteLine("il numero di produttori deve essere >=0 "); }
            }
            for (int i = 0; i < Nproduttori; i++)
            {
                produttori.Add(new Produttore_Random(i, bf));
            }

            while (Nproduttoriseq < 0)
            {
                Console.WriteLine("inserisci il numero di produttori sequenziali: ");
                Nproduttoriseq = Convert.ToInt32(Console.ReadLine());
                if (Nproduttoriseq < 0) { Console.WriteLine("il numero di produttori sequenziali deve essere >=0 "); }
            }
            for (int i = 0; i < Nproduttoriseq; i++)
            {
                produttoriseq.Add(new produttore_sequenziale(i, bf));
            }

            while (Nconsumatori < 0)
            {
                Console.WriteLine("inserisci il numero di consumatori: ");
                Nconsumatori = Convert.ToInt32(Console.ReadLine());
                if (Nconsumatori < 0) { Console.WriteLine("il numero di consumatori deve essere >=0 "); }
            }
            for (int i = 0; i < Nconsumatori; i++)
            {
                consumatori.Add(new Consumatore_random(i, bf));
            }

            Console.ReadKey();
        }

        private void RunAll()
        {

            for (int i = 0; i < Nconsumatori; i++)
            {
                Thread Threadconsumatore = new Thread(new ThreadStart(consumatori[i].Run));
                Threadconsumatore.Start();
                Threadlistc.Add(Threadconsumatore);
            }

            for (int i = 0; i < Nproduttori; i++)
            {
                Thread Threadproduttore = new Thread(new ThreadStart(produttori[i].Run));
                Threadproduttore.Start();
                Threadlistp.Add(Threadproduttore);
            }
            
            for (int i = 0; i < Nproduttoriseq; i++)
            {
                Thread Threadproduttoreseq = new Thread(new ThreadStart(produttoriseq[i].Run));
                Threadproduttoreseq.Start();
                Threadlistpseq.Add(Threadproduttoreseq);
            }

        }
    }
}