﻿using System;
using System.Threading.Tasks;

namespace produttore_consumatore_2._0
{
    class Produttore_Random : Utente_Random, interfaccia_produttore
    {
//costruttore
       public Produttore_Random(int ID, buffer buf)
        {
            id = ID;
            bf = buf;
            rnd = new Random((int)DateTime.Now.Ticks+id & 0x0000FFFF);
            Console.WriteLine("sono il produttore_Random {0}", id);
        }
//metodi
        public override void mostrastato()
        {
            Console.Write("P_R {0}, ", id);
            ProduciElemento();
            bf.mostrastato();
        }

        public async void ProduciElemento()
        {
            bool aggiunto;
            int elemento = rnd.Next(10, 99);
            lock (bf)
            {
                aggiunto = bf.ProvaAdAggiungere(elemento);  //1 istruzione!
            }

                if (aggiunto)
                {
                    Console.Write("aggiunto elemento {0} al buffer,                     ", elemento);
                }
                else
                {
                    Console.Write("impossibilitato ad aggiungere elemento {0} al buffer,", elemento);
                //async
                    await Task.Run(() => bf.attendibufferAsync());
                    Console.WriteLine("il buffer si è liberato per P_R {0}", id);
                //fine async
            }

        }
    }
}
