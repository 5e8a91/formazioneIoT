﻿using System;

namespace Template_Pasta
{
    class Pasta_alla_matriciana : Pasta
    {
        public override void PreparaIngredienti()
        {
            Console.WriteLine("     ingredienti per 2 persone:");
            Console.WriteLine("");
            Console.WriteLine("     150gr Di polpa di pomodoro fresco");
            Console.WriteLine("     60gr di Pancetta");
            Console.WriteLine("     25gr di pecorino romano stagionato grattuggiato");
            Console.WriteLine("     180gr di bucatini");
            Console.WriteLine("     1 cucchiaio di olio extra vergine di oliva");
            Console.WriteLine("     Sale q.b.");
            Console.WriteLine("     Peperoncino Rosso piccante");
        }
        public override void AssemblaCondimento()
        {
            Console.WriteLine(" metti un filo di olio e la pancetta tagliata a listarelle in una pentola.");
        }
        public override void Cuoci()
        {
            Console.WriteLine(" soffriggi la pancetta a fuoco dolce.");
            Console.WriteLine(" Appena sarà rosolata aggiungi la polpa di pomodoro e aggiungi il peperoncino con un pizzico di sale");
            Console.WriteLine(" cuoci i bucatini in acqua salata e scolali al dente");
            Console.WriteLine(" Versali nella pentola col sugo per terminare la cottura, facendoli saltare per un paio di minuti.");

        }
        public override void Impiatta()
        {
            Console.WriteLine(" A fuoco spento aggiungi il formaggio pecorino grattugiato al momento, fai le porzioni e porta in tavola immediatamente.");
            Console.WriteLine("        oooo         ");
            Console.WriteLine("      $$$$$$$$       ");
            Console.WriteLine("     SSS SSS SSS     ");
            Console.WriteLine("   <=============>   ");
            Console.WriteLine("");
            Console.WriteLine(" Il tuo piatto dovrebbe essere più o meno così... :-P ");
        }
    }
}
