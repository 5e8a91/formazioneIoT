﻿using System;

namespace Template_Pasta
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = "0";
            while (input!="1" && input!="2")
            {
            Console.WriteLine("quale pasta vuoi cucinare?");
            Console.WriteLine("1) Pasta alla matriciana");
            Console.WriteLine("2) Pasta al forno");
            input = Console.ReadLine();
            if (input == "1") {
                Pasta pasta1 = new Pasta_alla_matriciana();
                pasta1.TemplateMethod();
                }
                if (input == "2")
                {
                Pasta pasta2 = new Pasta_al_forno();
                pasta2.TemplateMethod();
                }
            if(input != "1" && input != "2")
                {
                    Console.WriteLine("ritenta, sarai più fortunato...");
                }
            }
            Console.ReadKey();
        }
    }
}
