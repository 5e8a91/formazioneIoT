﻿using System;

namespace Template_Pasta
{
    abstract class Pasta
    {
        public abstract void PreparaIngredienti();
        public abstract void AssemblaCondimento();
        public abstract void Cuoci();
        public abstract void Impiatta();

        // The "Template method"
        public void TemplateMethod()
        {
            Console.WriteLine("***************");
            Console.WriteLine("* INGREDIENTI *");
            Console.WriteLine("***************");
            Console.WriteLine("");
            PreparaIngredienti();
            Console.WriteLine("");
            Console.WriteLine("***************************");
            Console.WriteLine("* PREPARAZIONE CONDIMENTO *");
            Console.WriteLine("***************************");
            Console.WriteLine("");
            AssemblaCondimento();
            Console.WriteLine("");
            Console.WriteLine("***********");
            Console.WriteLine("* COTTURA *");
            Console.WriteLine("***********");
            Console.WriteLine("");
            Cuoci();
            Console.WriteLine("");
            Console.WriteLine("*****************");
            Console.WriteLine("* IMPIATTAMENTO *");
            Console.WriteLine("*****************");
            Console.WriteLine("");
            Impiatta();
            Console.WriteLine("");
            Console.WriteLine("******************");
            Console.WriteLine("* BUON APPETITO! *");
            Console.WriteLine("******************");
        }
    }


}
