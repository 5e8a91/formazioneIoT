﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template_Pasta
{
    class Pasta_al_forno : Pasta
    {
        public override void PreparaIngredienti()
        {
            Console.WriteLine("     ingredienti per 6 persone:");
            Console.WriteLine("");
            Console.WriteLine("     150 Gr Di Prosciutto Cotto A Fette");
            Console.WriteLine("     450 Gr Di Pasta Tipo Maccheroni");
            Console.WriteLine("     Parmigiano Grattugiato Q.B.");
            Console.WriteLine("     400 Gr Di Macinato Di Carne Magra");
            Console.WriteLine("     300 Gr Di Mozzarella");
            Console.WriteLine("     2 Uova");
            Console.WriteLine("     1 cucchiaio di olio extra vergine di oliva");
            Console.WriteLine("     1/2 Cipolla");
            Console.WriteLine("     Prezzemolo Q.B.");
            Console.WriteLine("     1 Litro Di Salsa Di Pomodoro");
            Console.WriteLine("     Pangrattato Q.B.");
            Console.WriteLine("     Prezzemolo Q.B.");
        }
        public override void AssemblaCondimento()
        {
            Console.WriteLine(" prendete il macinato di carne e mettetelo in una ciotola versando all'interno due uova intere");
            Console.WriteLine(" Aggiungete altri ingredienti come il pangrattato, il parmigiano, il sale, il prezzemolo e mescolate il composto.");
            Console.WriteLine(" Preparate una pentola e versate all’interno la cipolla tritata finemente,");
            Console.WriteLine(" un cucchiaio di olio, il sale e la salsa di pomodoro.");
            Console.WriteLine(" Iniziate a fare delle polpette di carne utilizzando il composto di macinato.");
            Console.WriteLine(" Tagliate a pezzetti la mozzarella ed il prosciutto cotto.");
        }
        public override void Cuoci()
        {
            Console.WriteLine(" Mettete a cuocere la salsa per 20 minuti.");
            Console.WriteLine(" Versate le polpette di carne nella pentola con la salsa e lasciate cuocere per altri 20 minuti.");
            Console.WriteLine(" Procuratevi poi un’altra pentola con dell’acqua salata e sbollentate al suo interno la pasta per pochi minuti");
            Console.WriteLine(" Dopo aver scolato la pasta, rimettetela in una pentola inumidendola con un po’ di salsa e con le polpette.");
            Console.WriteLine(" Trasferite la pasta in una teglia e aggiungete la  salsa restante, la mozzarella,il prosciutto e il parmigiano.");
            Console.WriteLine(" Cuocete in forno a 180° per circa 30 minuti");

        }
        public override void Impiatta()
        {
            Console.WriteLine(" Ultimata la cottura, fai le porzioni e porta in tavola immediatamente.");
            Console.WriteLine(" _____________________ ");
            Console.WriteLine(" |o$:oo:$%%%&&.:..oo: |");
            Console.WriteLine(" |$%:%&&o$:oo:$%.%&&: |");
            Console.WriteLine(" |o$:oo:$%%%&&.:..oo: |");
            Console.WriteLine(" |%&&oo:$%%.:..%&&oo: |");
            Console.WriteLine(" ----------------------");
            Console.WriteLine(" Il tuo piatto dovrebbe essere più o meno così... :-P ");
        }
    }
}
